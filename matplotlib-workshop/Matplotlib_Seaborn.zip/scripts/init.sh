pip install -r requirements.txt
cd ..
jupyter notebook